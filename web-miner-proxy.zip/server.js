const WebSocket = require("ws");
const net = require("net");
const http = require("http");
const express = require("express");

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static("."));

wss.on("connection", function(ws) {
  const tcp = net.connect(7019, "minotaurx.sea.mine.zpool.ca", () => {
    console.log("Connected to pool");
  });

  ws.on("message", msg => tcp.write(msg));
  tcp.on("data", data => ws.send(data));
  ws.on("close", () => tcp.end());
  tcp.on("end", () => ws.close());
});

server.listen(3000, () => console.log("Miner proxy running on port 3000"));
